﻿using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            {
                try
                {
                    string strVersionOrSize = string.Empty;
                    string strFileName = string.Empty; ;
                    if (args.Length==0 )
                    {
                        Console.WriteLine("No arguments were entered");
                        Console.ReadLine();
                    }
                    else
                    {
                        strVersionOrSize = args[0];
                        strFileName = args[1];

                        Console.WriteLine("Arguments Passed by the Programmer:" + strVersionOrSize + " " + strFileName);

                        if (!string.IsNullOrEmpty(strVersionOrSize) && (strVersionOrSize == "v" || strVersionOrSize == "-v" || strVersionOrSize == "--v"))
                        {
                            Console.WriteLine("Version = " + DisplayVersion(strVersionOrSize, strFileName));
                            Console.ReadLine();
                        }
                        if (!string.IsNullOrEmpty(strVersionOrSize) && (strVersionOrSize == "s" || strVersionOrSize == "-s" || strVersionOrSize == "--s"))
                        {
                            Console.WriteLine("Size =" + DisplaySize(strVersionOrSize, strFileName));
                            Console.ReadLine();
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error " + ex.Message.ToString());
                    Console.ReadLine();
                }

            }
        }

        public static string DisplayVersion(string strVersion, string strFileName)
        {
            FileDetails objfileVersion = new FileDetails();
            return objfileVersion.Version(strFileName);

        }
        public static int DisplaySize(string strSize, string strFileName)
        {
            FileDetails objfileSize = new FileDetails();
            return objfileSize.Size(strFileName);

        }
       
    }
}
